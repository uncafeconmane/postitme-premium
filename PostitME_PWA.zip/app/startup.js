/* Match the capability checks in the pinned Flutter 3.35.5 CanvasKit loader.
   The worker downloads only the renderer selected for this browser. */
(() => {
  const blink = navigator.vendor === 'Google Inc.' || navigator.userAgent.includes('Edg/');
  const chromium = blink && typeof ImageDecoder !== 'undefined' &&
    typeof Intl.v8BreakIterator !== 'undefined' && typeof Intl.Segmenter !== 'undefined';
  window.postitmeCanvasKitVariant = chromium ? 'chromium' : 'full';
  document.getElementById('retry').addEventListener('click', () => location.reload());

  window.addEventListener('flutter-first-frame', () => {
    document.getElementById('loading')?.remove();
    performance.mark('postitme-ready');
    if (!('serviceWorker' in navigator)) return;
    const register = async () => {
      try {
        const registration = await navigator.serviceWorker.register(
          `sw.js?renderer=${window.postitmeCanvasKitVariant}`, {updateViaCache: 'none'});
        const status = document.getElementById('offline-status');
        if (!registration.active) {
          status.hidden = false;
          status.textContent = 'Preparando el uso sin conexión…';
        }
        const ready = () => {
          status.hidden = false;
          status.textContent = 'Disponible sin conexión';
          setTimeout(() => { status.hidden = true; }, 3500);
        };
        // An active older worker is already offline-capable. A new one waits
        // until existing app tabs close, avoiding reloads during note editing.
        if (registration.active) return;
        const worker = registration.installing || registration.waiting;
        if (worker) worker.addEventListener('statechange', () => {
          if (worker.state === 'activated') ready();
          if (worker.state === 'redundant') {
            status.textContent = 'No se completó la descarga offline. Vuelve a abrir con conexión.';
          }
        });
        navigator.serviceWorker.ready.then(ready);
      } catch (_) {
        // Notes remain in encrypted local storage even if offline installation
        // is unavailable (private mode, quota, or a network interruption).
      }
    };
    // Do not compete with Dart/CanvasKit or vault opening for the first frame.
    if ('requestIdleCallback' in window) {
      requestIdleCallback(register, {timeout: 3000});
    } else {
      setTimeout(register, 1000);
    }
  }, {once: true});
})();
