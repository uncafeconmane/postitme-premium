const PREFIX = 'postitme:' + self.registration.scope + ':';
const RENDERER = new URL(self.location.href).searchParams.get('renderer') === 'chromium' ? 'chromium' : 'full';
const CACHE = PREFIX + '1cbf22262ddb3a38:' + RENDERER;
const ASSETS = ["./assets/AssetManifest.bin", "./assets/AssetManifest.bin.json", "./assets/AssetManifest.json", "./assets/FontManifest.json", "./assets/NOTICES", "./assets/assets/fonts/Inter-Regular.ttf", "./assets/assets/fonts/OFL.txt", "./assets/assets/icons/postitme.svg", "./assets/fonts/MaterialIcons-Regular.otf", "./assets/packages/cupertino_icons/assets/CupertinoIcons.ttf", "./assets/packages/record_web/assets/js/record.fixwebmduration.js", "./assets/packages/record_web/assets/js/record.worklet.js", "./assets/shaders/ink_sparkle.frag", "./canvaskit/canvaskit.js", "./canvaskit/canvaskit.wasm", "./canvaskit/chromium/canvaskit.js", "./canvaskit/chromium/canvaskit.wasm", "./favicon.png", "./flutter.js", "./flutter_bootstrap.js", "./icons/Icon-192.png", "./icons/Icon-512.png", "./icons/Icon-maskable-192.png", "./icons/Icon-maskable-512.png", "./index.html", "./main.dart.js", "./main.dart.js_1.part.js", "./manifest.json", "./startup.js", "./version.json"].filter(path => !path.startsWith('./canvaskit/') ||
  (RENDERER === 'chromium' ? path.startsWith('./canvaskit/chromium/') : !path.startsWith('./canvaskit/chromium/')));
const SCOPE = new URL(self.registration.scope);
const ALLOWED = new Set(ASSETS.map(path => new URL(path, SCOPE).href));

self.addEventListener('install', event => event.waitUntil((async () => {
  const cache = await caches.open(CACHE);
  // A fresh response is required for versionless Flutter URLs; otherwise the
  // HTTP cache could install a previous main.dart.js under the new version.
  // Bounded concurrency avoids a burst of requests on mid-range phones.
  let next = 0;
  await Promise.all(Array.from({length: 3}, async () => {
    while (next < ASSETS.length) {
      const url = new URL(ASSETS[next++], SCOPE).href;
      const response = await fetch(new Request(url, {cache: 'reload'}));
      if (!response.ok) throw new Error('Offline resource unavailable');
      await cache.put(url, response);
    }
  }));
})()));

self.addEventListener('activate', event => event.waitUntil((async () => {
  const keys = await caches.keys();
  await Promise.all(keys.filter(key => key.startsWith(PREFIX) && key !== CACHE).map(key => caches.delete(key)));
  await self.clients.claim();
})()));

self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (event.request.method !== 'GET' || url.origin !== SCOPE.origin || !url.pathname.startsWith(SCOPE.pathname)) return;
  // Never intercept Auth redirects, API calls, attachments or arbitrary paths.
  if (/\/(auth|api)(\/|$)/.test(url.pathname)) return;
  if (event.request.mode === 'navigate') {
    if (url.pathname !== SCOPE.pathname && url.pathname !== SCOPE.pathname + 'index.html') return;
    event.respondWith(caches.open(CACHE).then(async cache =>
      (await cache.match(new URL('./index.html', SCOPE).href)) || fetch(event.request)));
    return;
  }
  url.search = '';
  if (!ALLOWED.has(url.href)) return;
  event.respondWith(caches.open(CACHE).then(async cache =>
    (await cache.match(url.href)) || fetch(event.request)));
});
